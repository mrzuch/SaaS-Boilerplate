export interface SetupExecutorSchema {
    cwd: string;
    envSharedFile?: string;
    envFileOutput?: string;
}
