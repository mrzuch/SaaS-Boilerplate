SERIALIZER_CLASS_REQUIRED_ERROR = "serializer_class is required for the SerializerMutation"
