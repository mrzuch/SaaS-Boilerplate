from enum import Enum


class Subscription(Enum):
    NOTIFICATIONS_LIST_SUBSCRIPTION = "notificationsListSubscription"
