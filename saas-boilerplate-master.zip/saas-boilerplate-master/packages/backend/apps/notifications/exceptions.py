class NotificationStrategyException(Exception):
    pass
